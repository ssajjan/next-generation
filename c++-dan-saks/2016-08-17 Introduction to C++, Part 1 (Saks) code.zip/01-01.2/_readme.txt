hello - print "Hello, world"

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This is the same as the previous version, except:

1. the source file has a .cpp extension, and

2. it comes only with make files that implicitly compile as C++.

