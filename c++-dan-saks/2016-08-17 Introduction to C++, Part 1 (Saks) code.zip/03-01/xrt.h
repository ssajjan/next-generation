// xrt.h - cross-reference table interface

// Copyright (c) 2016 by Dan Saks.

// See _readme.txt.

void xrt_add(char *w, unsigned n);
void xrt_put();
void xrt_sort();

