hello - greet the user by name

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This version prompts the user to enter his/her name and then greets
him/her by that name.

