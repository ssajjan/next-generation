// hello.cpp

// Copyright (c) 2016 by Dan Saks.

// See _readme.txt.

#include <stdio.h>
#include "hello.h"

void hello() {
	printf("Hello, world\n");
}

