// hello.h

// Copyright (c) 2016 by Dan Saks.

// See _readme.txt.

void hello();

