// greet.cpp

// Copyright (c) 2016 by Dan Saks.

// See _readme.txt.

#include "hello.h"

int main() {
	hello();
	return 0;
}

