sum - sum up the elements in an integer array

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

Use the files in this folder to solve the exercise.

