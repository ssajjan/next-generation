xr - a cross-reference generator

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This version introduces const objects in place of object-like macros. It
doesn't compile in C.

It doesn't compile in C++ either -- not because of the const objects, but
because of invalid pointer conversions to be eliminated in a later
exercise.

