// hello.cpp

// Copyright (c) 2016 by Dan Saks.

// See _readme.txt.

#include <iostream>

using namespace std;

int main() {
	std::cout << "Hello, world\n";
	return 0;
}

