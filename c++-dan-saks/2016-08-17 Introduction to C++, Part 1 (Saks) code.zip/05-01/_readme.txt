hello - write "Hello, world" to standard output

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This version uses the fully-qualified name std::cout to refer to the
standard output stream.

