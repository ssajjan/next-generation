mystrlen - a function similar to strlen

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This implements and tests an implementation of a function similar to the
Standard strlen function. It uses pointer notation and a for loop.

