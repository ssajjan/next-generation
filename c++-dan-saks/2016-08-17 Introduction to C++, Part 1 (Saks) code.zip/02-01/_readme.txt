xr - a cross-reference generator

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This is the first version of the cross-reference generator. Aside from
using slash-slash comments, it's a C90 program in a classic procedural
style implemented in a single source file.

