demo - demonstrate brace initialization

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This program demostrates the use of brace initialization for an array of
class objects.

It also illustrates the use of brace initialization in an
array-new-expression in C++11.

