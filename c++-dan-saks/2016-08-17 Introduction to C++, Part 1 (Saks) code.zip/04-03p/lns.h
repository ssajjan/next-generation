// lns.h - line number set interface

// Copyright (c) 2016 by Dan Saks.

// See _readme.txt.

// fill in the rest of this

