xr - a cross-reference generator

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

Use these files to solve this exercise.

This version of xr is the same as the previous one. However, this folder
includes stubs for the lns.h and lns.cpp files. It also includes makefiles
for building the program with the lns files.

