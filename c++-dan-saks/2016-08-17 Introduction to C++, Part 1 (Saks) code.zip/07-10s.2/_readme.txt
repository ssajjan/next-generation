xr - a cross-reference generator

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This version introduces destructors for all the classes in the program.
Each destructor includes a statement to decrement and display the counter.
The lns destructor in this version uses recursion.

