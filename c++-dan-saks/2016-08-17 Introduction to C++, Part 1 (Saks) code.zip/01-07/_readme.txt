swap - swap integers by value

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the "notice.txt" file.

This version of the swap function passes its arguments by value.

