xr - a cross-reference generator

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This version uses the <cheader> standard headers in place of the
<header.h> headers.

