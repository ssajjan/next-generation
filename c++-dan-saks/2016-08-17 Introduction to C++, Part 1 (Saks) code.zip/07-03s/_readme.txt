testfa - test float_array

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This program tests the functions of the float_array class.

This float_array class introduces the default constructor and the copy
constructor.

