// hello.cpp

// Copyright (c) 2016 by Dan Saks.

// See _readme.txt.

#include <iostream>

int main() {
	using namespace std;
	cout << "Hello, world\n";
	return 0;
}

