narrow - narrowing conversion demo

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This program attempts to provoke the compiler to issue warnings for
narrowing conversions.

