hello - write "Hello, world"

Copyright (c) 2016 by Dan Saks. Do not distribute any of the files in this
folder without the file notice.txt.

This compiles as either Standard C or Standard C++.

The source file has a .c extension. The C++ make files use a compile
option to force the compiler to compile as C++.

